import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase, type User } from './supabase';
import { ProfileType } from '@shared/api';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  error: string | null;
  signUp: (
    email: string,
    password: string,
    username: string,
    activeProfile: ProfileType,
    profiles: ProfileType[],
    tier: 'Basic' | 'Standard' | 'Premium'
  ) => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;

    const initAuth = async () => {
      try {
        const { data } = await supabase.auth.getSession();
        if (data.session?.user) {
          await fetchUserProfile(data.session.user.id);
        }
        if (isMounted) setLoading(false);
      } catch (err) {
        console.error('Auth check failed:', err);
        if (isMounted) setLoading(false);
      }
    };

    initAuth();

    const { data } = supabase.auth.onAuthStateChange((event, session) => {
      if (!isMounted) return;
      if (session?.user) {
        void fetchUserProfile(session.user.id);
      } else {
        setUser(null);
      }
    });

    return () => {
      isMounted = false;
      data?.subscription?.unsubscribe();
    };
  }, []);

  const fetchUserProfile = async (userId: string) => {
    try {
      const { data: profile, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .single();

      if (error) {
        console.error('Failed to fetch user profile:', error);
        const { data: authUser } = await supabase.auth.getUser();
        if (authUser.user) {
          setUser({
            id: authUser.user.id,
            email: authUser.user.email || '',
            username: authUser.user.user_metadata?.username || 'user_' + authUser.user.id.slice(0, 8),
            role: (authUser.user.user_metadata?.role as User['role']) || 'fan',
            avatar_url: authUser.user.user_metadata?.avatar_url,
            created_at: authUser.user.created_at || new Date().toISOString(),
          });
        }
        return;
      }

      setUser(profile);
    } catch (err) {
      console.error('Error fetching user profile:', err);
    }
  };

  const signUp = async (
    email: string,
    password: string,
    username: string,
    activeProfile: ProfileType,
    profiles: ProfileType[],
    tier: 'Basic' | 'Standard' | 'Premium'
  ) => {
    try {
      setError(null);

      // Check if email is already registered by attempting a password sign-in with a dummy
      // password — the safest way is to use signUp and inspect the response carefully.
      // Supabase returns identities: [] when the email already exists (email confirmation off).
      const { data, error: signUpError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: { username, role: activeProfile, profiles, tier },
        },
      });

      if (signUpError) throw signUpError;

      // If identities array is empty, the email is already registered
      if (data.user && (!data.user.identities || data.user.identities.length === 0)) {
        throw new Error('This email is already registered. Please sign in instead.');
      }

      if (data.user) {
        setTimeout(() => fetchUserProfile(data.user!.id), 1000);
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Sign up failed';
      setError(message);
      throw err;
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      setError(null);
      const { data, error: signInError } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (signInError) {
        if (signInError.message.includes('invalid login') || signInError.message.includes('Invalid')) {
          throw new Error('Invalid email or password');
        } else if (signInError.message.includes('not confirmed')) {
          throw new Error('Please confirm your email before signing in');
        } else {
          throw signInError;
        }
      }

      if (data.user) {
        await fetchUserProfile(data.user.id);
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Sign in failed';
      setError(message);
      throw err;
    }
  };

  const signOut = async () => {
    try {
      setError(null);
      const { error: signOutError } = await supabase.auth.signOut();
      if (signOutError) throw signOutError;
      setUser(null);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Sign out failed';
      setError(message);
      throw err;
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, error, signUp, signIn, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
}
