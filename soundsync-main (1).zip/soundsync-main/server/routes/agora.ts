import { RequestHandler } from "express";
import agoraToken from "agora-token";

const { RtcTokenBuilder, RtcRole } = agoraToken;

// Agora RTC Token generation

export const generateAgoraToken: RequestHandler = (req, res) => {
  try {
    const { channelName, uid } = req.body;

    if (!channelName || !uid) {
      return res.status(400).json({ error: "channelName and uid required" });
    }

    const AGORA_APP_ID = process.env.AGORA_APP_ID;
    const AGORA_APP_CERTIFICATE = process.env.AGORA_APP_CERTIFICATE;

    if (!AGORA_APP_ID || !AGORA_APP_CERTIFICATE) {
      // For development without Agora setup, return a mock token
      return res.json({
        token: `mock_token_${Date.now()}`,
        channelName,
        uid,
        message: "Using mock token. Set AGORA_APP_ID and AGORA_APP_CERTIFICATE for real tokens",
      });
    }

    // Generate real token
    const role = RtcRole.PUBLISHER; // Can publish audio
    const expirationTimeInSeconds = 3600; // 1 hour
    const currentTimestamp = Math.floor(Date.now() / 1000);
    const privilegeExpiredTs = currentTimestamp + expirationTimeInSeconds;

    const token = RtcTokenBuilder.buildTokenWithUid(
      AGORA_APP_ID,
      AGORA_APP_CERTIFICATE,
      channelName,
      uid,
      role,
      privilegeExpiredTs, // token expire
      privilegeExpiredTs  // privilege expire
    );

    res.json({
      token,
      channelName,
      uid,
    });
  } catch (error) {
    console.error('Error generating Agora token:', error);
    res.status(500).json({ error: "Token generation failed" });
  }
};
